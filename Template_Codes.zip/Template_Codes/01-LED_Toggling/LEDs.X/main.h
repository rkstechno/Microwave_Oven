/* 
 * File:   main.h
 * Author: Emertxe
 *
 * Created on March 7, 2022, 7:20 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED_ARRAY       PORTD
#define LED_ARRAY_DDR   TRISD

#endif	/* MAIN_H */

