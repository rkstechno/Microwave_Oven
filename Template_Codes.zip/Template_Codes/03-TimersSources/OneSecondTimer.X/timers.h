/* 
 * File:   timers.h
 * Author: CFT
 *
 * Created on 28 April, 2020, 6:42 PM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);

#endif	/* TIMERS_H */

