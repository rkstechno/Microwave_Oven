/* 
 * File:   main.h
 * Author: Emertxe
 *
 * Created on 11 September, 2023, 8:33 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define LED4_DDR TRISD4
#define LED4    RD4 

#endif	/* MAIN_H */

